DBMS Commerce - Final Admin Product Edit + Image Fix

Changes in this version:
1. Admin Inventory Edit now reliably updates product name, description, category, price and stock quantity.
2. Existing-product update checks the product first, so saving unchanged values is still treated as a successful update.
3. Added Product Image upload in the Admin Product modal.
4. Images are resized in the browser and stored in products.image_url as a data URL.
5. Existing databases are automatically migrated on server startup by adding products.image_url if it is missing.
6. Product images are shown in the Admin Inventory table and storefront product cards.
7. Best Sellers fix from the previous working version is preserved.

Run:
  npm install
  npm start

Open:
  http://localhost:5000/admin.html

After replacing an older local project, restart the server and use Ctrl+F5 in the browser.

DBMS Commerce - Final Project

This package preserves the original folder structure and fixes the module paths.

Structure:
  config/db.js
  db/ecommerce_db.sql
  public/index.html
  public/admin.html
  public/js/main.js
  public/js/admin.js
  routes/features.js
  server.js
  package.json
  package-lock.json

Run:
1. Make sure MySQL is running.
2. Import db/ecommerce_db.sql into MySQL if the ecommerce_db database is not already set up.
3. Verify config/db.js has the correct MySQL username/password.
4. Open terminal in this project folder.
5. Run: npm install
6. Run: npm start
7. Open: http://localhost:5000/
8. Admin page: http://localhost:5000/admin.html

Important path rules:
  server.js -> ./config/db
  server.js -> ./routes/features
  routes/features.js -> ../config/db
  server.js serves the public folder.
